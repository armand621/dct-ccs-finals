<?php
    // Logout Code Here
    require '../functions.php';
    $indexPage = '../index.php';
    logout($indexPage);
?>